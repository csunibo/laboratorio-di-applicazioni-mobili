package it.unibo.stradivarius.intentdialer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SelectorActivity extends AppCompatActivity {

    Button btnUK;
    Button btnIT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selector);

        btnUK = findViewById(R.id.buttonUK);
        btnUK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = getIntent();
                setResult(RESULT_OK, i);
                i.putExtra("prefix", btnUK.getText());
                finish();
            }
        });
        btnIT = findViewById(R.id.buttonIT);
        btnIT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = getIntent();
                setResult(RESULT_OK, i);
                i.putExtra("prefix", btnIT.getText());
                finish();
            }
        });
    }
}