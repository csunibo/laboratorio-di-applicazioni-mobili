//
//  ViewController.swift
//  PrimaDemo2022
//
//  Created by Luciano Bononi on 10/03/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
   
    var count : Int = 0

    @IBAction func secondAction(_ sender: UIButton) {
       count = count + 1
    
        countLabel.text = "\(count)"
        if myLabel.text == "" {
            myLabel.text = "HOUCH!!!"
        } else {
            myLabel.text = ""
        }
    }
    
    @IBAction func myButtonTouch(_ sender: UIButton) {
        count = count + 1
        countLabel.text = "\(count)"
        if myLabel.text == "" {
            myLabel.text = "HEY!!!"
        } else {
            myLabel.text = ""
        }
    }
    
    
    @IBOutlet weak var countLabel: UILabel!
    
    @IBOutlet weak var myLabel: UILabel!
}

