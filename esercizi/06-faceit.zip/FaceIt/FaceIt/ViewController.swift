//
//  ViewController.swift
//  FaceIt
//
//  Created by Luciano Bononi on 10/05/17.
//  Copyright © 2017 Luciano Bononi. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var myFace: FaceView!
    
    @IBAction func eyesOpen(_ sender: UISwitch) {
          myFace.eyesOpen = sender.isOn
          myFace.setNeedsDisplay()
    }
    
    @IBAction func smilingness(_ sender: UISlider) {
        myFace.mouthCurvature = Double(sender.value) * 2.0 - 1.0
        myFace.setNeedsDisplay()
    }
}

