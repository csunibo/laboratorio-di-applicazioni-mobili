//
//  Concentration.swift
//  GiocoDiCarte-fase2
//
//  Created by Luciano Bononi on 12/03/2020.
//  Copyright © 2020 Luciano Bononi. All rights reserved.
//

import Foundation

class Concentration {
//    var cards: Array<Card>()
    var cards = [Card]()
    
    var indexOfOneAndOnlyfaceUpCard: Int?
    
    func chooseCard(at index: Int) {
        if !cards[index].isMatched {
            if let matchIndex = indexOfOneAndOnlyfaceUpCard, matchIndex != index {
                // check if cards match
                if cards[matchIndex].identifier == cards[index].identifier {
                    cards[matchIndex].isMatched = true
                    cards[index].isMatched = true
                }
                cards[index].isFaceUp = true
                indexOfOneAndOnlyfaceUpCard = nil
            } else {
                for flipDownIndex in cards.indices {
                    cards[flipDownIndex].isFaceUp = false
                }
                cards[index].isFaceUp = true
                indexOfOneAndOnlyfaceUpCard = index
            }
            //1 no card is face up
            //2 two cards face up, this card is the new one of a pair
            //3 one card faceUp yet, chosen 2nd one index, check match?
        }
        // gestisce il flip delle card nel modello
//        if cards[index].isFaceUp {
//            cards[index].isFaceUp = false
//        } else {
//            cards[index].isFaceUp = true
//        }
    }
    
    init(numberOfPairsOfCards: Int){
        for _ in 0..<numberOfPairsOfCards {
            let card = Card()
//            let matchingCard = card
//            cards.append(card)
//            cards.append(card)
            cards += [card, card]
    }
        // TODO: shuffle cards
}
}
